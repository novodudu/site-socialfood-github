import React from "react";

const Somos = (props) => {
  return (
    <div id="somos">
      <div class="conteudo-somos">
        <h1>
          Somo a primeira rede social de deliveri. Viemos com o mesmo objetivo
          de conectar pessoas.
        </h1>
        <h2>
          Nosso app disponibiliza uma fução onde os usuários poderão convidar
          terceiros para fazer compras compartilhadas. A idéia é unir pessoas
          para consumir produtos juntas. Nós somo tendência, somos o futuro.
        </h2>
      </div>
    </div>
  );
};

export default Somos;
